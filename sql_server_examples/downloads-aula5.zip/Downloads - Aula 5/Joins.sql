DROP TABLE T_heap1
DROP TABLE T_heap2
CREATE TABLE T_heap1 (a int NOT NULL, b int NOT NULL, c int NOT NULL, d int NOT NULL, e int NOT NULL, f int NOT NULL); 

insert into T_heap1 (a,b,c,d,e,f) values (1, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),1)
insert into T_heap1 (a,b,c,d,e,f) values (2, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),2)
insert into T_heap1 (a,b,c,d,e,f) values (3, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),3)
insert into T_heap1 (a,b,c,d,e,f) values (4, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),4)
insert into T_heap1 (a,b,c,d,e,f) values (5, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),5)
insert into T_heap1 (a,b,c,d,e,f) values (6, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),6)
insert into T_heap1 (a,b,c,d,e,f) values (7, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),7)
insert into T_heap1 (a,b,c,d,e,f) values (8, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),8)
insert into T_heap1 (a,b,c,d,e,f) values (9, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),9)
insert into T_heap1 (a,b,c,d,e,f) values (10, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),10)
insert into T_heap1 (a,b,c,d,e,f) values (11, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),11)
insert into T_heap1 (a,b,c,d,e,f) values (12, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),12)
insert into T_heap1 (a,b,c,d,e,f) values (13, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),13)
insert into T_heap1 (a,b,c,d,e,f) values (14, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),14)
insert into T_heap1 (a,b,c,d,e,f) values (15, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),15)
insert into T_heap1 (a,b,c,d,e,f) values (16, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),16)
insert into T_heap1 (a,b,c,d,e,f) values (17, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),17)
insert into T_heap1 (a,b,c,d,e,f) values (18, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),18)
insert into T_heap1 (a,b,c,d,e,f) values (19, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),19)
insert into T_heap1 (a,b,c,d,e,f) values (20, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),20)
insert into T_heap1 (a,b,c,d,e,f) values (21, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),21)

CREATE TABLE T_heap2 (a int NOT NULL, b int NOT NULL, c int NOT NULL, d int NOT NULL, e int NOT NULL, f int NOT NULL); 

insert into T_heap2 (a,b,c,d,e,f) values (1, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),1)
insert into T_heap2 (a,b,c,d,e,f) values (2, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),2)
insert into T_heap2 (a,b,c,d,e,f) values (3, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),3)
insert into T_heap2 (a,b,c,d,e,f) values (4, [dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),[dbo].[NumeroAleatorio](1,100),4)

SELECT T_heap1.a, T_heap2.a from T_heap1 INNER JOIN T_heap2 ON T_heap1.a = T_heap2.a

SELECT T_heap1.a, T_heap2.a from T_heap1 INNER JOIN T_heap2 ON T_heap1.a = T_heap2.a
where T_heap1.a <=2 

CREATE INDEX T_heap1_a ON T_heap1 (a);
DROP INDEX  T_heap1_a ON T_heap1

CREATE INDEX T_heap2_a ON T_heap2 (a);
DROP INDEX  T_heap2_a ON T_heap2



