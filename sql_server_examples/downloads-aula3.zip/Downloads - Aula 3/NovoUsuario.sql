
CREATE LOGIN marcos WITH PASSWORD = 'marcos@123'

