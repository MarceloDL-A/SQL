
ALTER SERVER ROLE [dbcreator] ADD MEMBER [marco] 

ALTER SERVER ROLE [dbcreator] DROP MEMBER [marco] 