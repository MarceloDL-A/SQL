
SELECT * FROM SYS.fn_builtin_permissions('') WHERE CLASS_DESC = 'SERVER'